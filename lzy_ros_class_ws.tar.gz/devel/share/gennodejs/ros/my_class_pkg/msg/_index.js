
"use strict";

let MyMessage = require('./MyMessage.js');
let MyActionActionFeedback = require('./MyActionActionFeedback.js');
let MyActionResult = require('./MyActionResult.js');
let MyActionActionResult = require('./MyActionActionResult.js');
let MyActionFeedback = require('./MyActionFeedback.js');
let MyActionActionGoal = require('./MyActionActionGoal.js');
let MyActionGoal = require('./MyActionGoal.js');
let MyActionAction = require('./MyActionAction.js');

module.exports = {
  MyMessage: MyMessage,
  MyActionActionFeedback: MyActionActionFeedback,
  MyActionResult: MyActionResult,
  MyActionActionResult: MyActionActionResult,
  MyActionFeedback: MyActionFeedback,
  MyActionActionGoal: MyActionActionGoal,
  MyActionGoal: MyActionGoal,
  MyActionAction: MyActionAction,
};
